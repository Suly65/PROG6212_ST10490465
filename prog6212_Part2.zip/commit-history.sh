#!/usr/bin/env bash
# RaceDay Part 2 - commit helper (run in Git Bash from the ROOT of your repository
# AFTER copying the contents of the "RaceDay" folder into it).
#
# Each commit stages one real piece of the work, so your history tells the story of how the
# API was built. Commits use YOUR git identity (git config user.name / user.email).
# Run these steps in order. Step 10 needs you to have run Add-Migration first (see guide).

git checkout -b part2-api 2>/dev/null || git checkout part2-api

c() {
  if git add "${@:2}" 2>/dev/null && ! git diff --cached --quiet; then
    git commit -q -m "$1" && echo "committed: $1"
  else
    echo "SKIPPED (nothing to commit / path missing): $1"
  fi
}

c "Preserve original Part 1 planning documents"          docs/part1-original
c "Update ERD with event distance and event type"        docs/RaceDay_ERD.png docs/RaceDay_ERD.pdf
c "Update SQL script to match Part 2 data model"         docs/RaceDay_Schema.sql
c "Add Part 2 API endpoint plan"                         docs/API_Endpoint_Plan_Part2.md
c "Create RaceDay solution and API project"              RaceDay.sln .gitignore RaceDay.Api/RaceDay.Api.csproj RaceDay.Api/Properties
c "Add RaceDay DTO classes"                              RaceDay.Contracts
c "Create entity models"                                 RaceDay.Api/Models
c "Configure RaceDayDbContext relationships and constraints" RaceDay.Api/Data
c "Add SQL Server connection and session setup"          RaceDay.Api/appsettings.json RaceDay.Api/Program.cs

# ---- STEP 10: run  Add-Migration InitialRaceDayDatabase  and  Update-Database  first ----
c "Create initial EF migration"                          RaceDay.Api/Migrations

c "Add password hashing service"                         RaceDay.Api/Services
c "Add role-based access filter"                         RaceDay.Api/Filters
c "Add controller base class and DTO mapping"            RaceDay.Api/Controllers/ApiControllerBase.cs RaceDay.Api/Mapping
c "Add registration, login and logout with session handling" RaceDay.Api/Controllers/AuthController.cs
c "Add profile endpoints"                                RaceDay.Api/Controllers/ProfileController.cs
c "Add event endpoints with organiser ownership checks"  RaceDay.Api/Controllers/EventsController.cs
c "Add category endpoints"                               RaceDay.Api/Controllers/CategoriesController.cs
c "Add participant enrolment and organiser enrolment view" RaceDay.Api/Controllers/EnrolmentsController.cs
c "Add results endpoints"                                RaceDay.Api/Controllers/ResultsController.cs
c "Add test project with in-memory test factory"         RaceDay.Api.Tests/RaceDay.Api.Tests.csproj RaceDay.Api.Tests/RaceDayFactory.cs RaceDay.Api.Tests/TestHelpers.cs
c "Add authentication unit tests"                        RaceDay.Api.Tests/AuthenticationTests.cs
c "Add role-based access tests"                          RaceDay.Api.Tests/RoleEnforcementTests.cs
c "Add event and category management tests"              RaceDay.Api.Tests/EventManagementTests.cs
c "Add enrolment and result tests"                       RaceDay.Api.Tests/EnrolmentAndResultTests.cs
c "Configure GitHub Actions build and test workflow"     .github/workflows/ci.yml
c "Update README for Part 2"                             README.md

git status --short
echo "Done. Now: git push -u origin part2-api"
